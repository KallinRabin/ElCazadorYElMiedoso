/**
 * Componente Principal de la Aplicación (App.tsx)
 * Conecta el Motor 3D de GameManager con la interfaz de usuario en React
 */

import React, { useEffect, useRef, useState } from 'react';
import { GameManager } from './game/GameManager';
import { HUD } from './components/HUD';
import { StartScreen } from './components/StartScreen';
import { SettingsModal } from './components/SettingsModal';
import { GameOverModal } from './components/GameOverModal';
import { ControlsGuide } from './components/ControlsGuide';
import { GameConfig, GameState, MatchStats, PlayerRole, PlayerStats, DEFAULT_CONFIG } from './types';
import { Lock, MousePointer } from 'lucide-react';

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const gameManagerRef = useRef<GameManager | null>(null);

  const [gameState, setGameState] = useState<GameState>(GameState.MENU);
  const [config, setConfig] = useState<GameConfig>(DEFAULT_CONFIG);
  const [playerStats, setPlayerStats] = useState<PlayerStats | null>(null);
  const [matchStats, setMatchStats] = useState<MatchStats | null>(null);
  const [interactionPrompt, setInteractionPrompt] = useState<string | null>(null);
  const [roleAlert, setRoleAlert] = useState<{ role: PlayerRole; message: string } | null>(null);
  const [damageFlash, setDamageFlash] = useState<boolean>(false);
  const [hitMarker, setHitMarker] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isPointerLocked, setIsPointerLocked] = useState<boolean>(false);

  // 1. Inicialización de GameManager
  useEffect(() => {
    const gm = new GameManager(config);
    gameManagerRef.current = gm;

    if (canvasRef.current) {
      gm.initRenderer(canvasRef.current);
    }

    // Callbacks de eventos
    gm.onStateChange((newState, stats) => {
      setGameState(newState);
      setMatchStats(stats);
      if (document.pointerLockElement) {
        document.exitPointerLock();
      }
    });

    gm.onRoleAlert((role, message) => {
      setRoleAlert({ role, message });
      setTimeout(() => setRoleAlert(null), 3500);
    });

    gm.onHitEffect((type) => {
      if (type === 'damage') {
        setDamageFlash(true);
        setTimeout(() => setDamageFlash(false), 200);
      } else {
        setHitMarker(true);
        setTimeout(() => setHitMarker(false), 150);
      }
    });

    // Bucle de sincronización de estadísticas React (60fps)
    const statsInterval = setInterval(() => {
      if (gm.gameState === GameState.PLAYING) {
        setPlayerStats(gm.player.getStats());
        setMatchStats(gm.getMatchStats());
        const target = gm.player.interactionSystem.getCurrentTarget();
        setInteractionPrompt(target ? target.getPrompt() : null);
      }
    }, 1000 / 60);

    return () => {
      clearInterval(statsInterval);
      gm.destroy();
    };
  }, []);

  // 2. Control de Pointer Lock y Eventos de Ratón / Teclado
  useEffect(() => {
    const handlePointerLockChange = () => {
      const locked = document.pointerLockElement === canvasRef.current;
      setIsPointerLocked(locked);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Escape' && gameState === GameState.PLAYING) {
        // ESC libera pointer lock
        return;
      }
      gameManagerRef.current?.player.onKeyDown(e);
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      gameManagerRef.current?.player.onKeyUp(e);
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement === canvasRef.current) {
        gameManagerRef.current?.player.onMouseMove(e.movementX, e.movementY);
      }
    };

    const handleMouseDown = (e: MouseEvent) => {
      if (document.pointerLockElement === canvasRef.current) {
        gameManagerRef.current?.player.onMouseDown(e.button);
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (document.pointerLockElement === canvasRef.current) {
        gameManagerRef.current?.player.onMouseUp(e.button, (arrow) => {
          gameManagerRef.current?.shootPlayerArrow(arrow);
        });
      }
    };

    document.addEventListener('pointerlockchange', handlePointerLockChange);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('pointerlockchange', handlePointerLockChange);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [gameState]);

  const requestPointerLock = () => {
    if (canvasRef.current && gameState === GameState.PLAYING) {
      canvasRef.current.requestPointerLock();
    }
  };

  const handleStartMatch = (customConfig?: Partial<GameConfig>) => {
    if (customConfig) {
      const merged = { ...config, ...customConfig };
      setConfig(merged);
      gameManagerRef.current?.startMatch(merged);
    } else {
      gameManagerRef.current?.startMatch(config);
    }
    setGameState(GameState.PLAYING);
    setTimeout(requestPointerLock, 100);
  };

  const handleSaveConfig = (newConfig: GameConfig) => {
    setConfig(newConfig);
    if (gameManagerRef.current) {
      gameManagerRef.current.config = newConfig;
      gameManagerRef.current.player.configure(newConfig);
      gameManagerRef.current.roleManager.configure(newConfig.roleSwitchTime);
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 select-none font-sans">
      {/* Canvas 3D de Three.js */}
      <canvas
        ref={canvasRef}
        onClick={requestPointerLock}
        className="w-full h-full block cursor-crosshair focus:outline-none"
      />

      {/* Indicador de "Haz click para controlar la cámara" si no tiene pointer lock */}
      {gameState === GameState.PLAYING && !isPointerLocked && !isSettingsOpen && (
        <div
          onClick={requestPointerLock}
          className="absolute inset-0 bg-slate-950/40 backdrop-blur-[2px] z-10 flex flex-col items-center justify-center cursor-pointer pointer-events-auto"
        >
          <div className="bg-slate-900/90 border border-amber-500/60 text-amber-300 px-6 py-3.5 rounded-2xl shadow-2xl flex items-center gap-3 animate-pulse">
            <MousePointer className="w-5 h-5 text-amber-400" />
            <span className="text-sm font-bold tracking-wide">
              Haz click aquí para activar el ratón en primera persona
            </span>
          </div>
        </div>
      )}

      {/* Botón flotante de controles y ajustes */}
      {gameState === GameState.PLAYING && (
        <ControlsGuide onOpenSettings={() => setIsSettingsOpen(true)} />
      )}

      {/* HUD del Juego */}
      {gameState === GameState.PLAYING && (
        <HUD
          playerStats={playerStats}
          matchStats={matchStats}
          interactionPrompt={interactionPrompt}
          roleAlert={roleAlert}
          damageFlash={damageFlash}
          hitMarker={hitMarker}
          onOpenSettings={() => setIsSettingsOpen(true)}
        />
      )}

      {/* Pantalla de Inicio / Menú */}
      {gameState === GameState.MENU && (
        <StartScreen
          config={config}
          onStartMatch={handleStartMatch}
          onOpenSettings={() => setIsSettingsOpen(true)}
        />
      )}

      {/* Modal de Fin de Partida (Victoria / Derrota) */}
      {gameState === GameState.GAME_OVER && (
        <GameOverModal
          stats={matchStats}
          onRematch={() => handleStartMatch()}
          onReturnToMenu={() => setGameState(GameState.MENU)}
        />
      )}

      {/* Modal de Configuración & Documentación */}
      <SettingsModal
        config={config}
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        onSaveConfig={handleSaveConfig}
      />
    </div>
  );
}
