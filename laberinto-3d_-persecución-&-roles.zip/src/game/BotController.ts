/**
 * Controlador de IA para el Segundo Jugador (Bot Rival)
 * Modos de comportamiento según rol (Cazador agresivo vs Corredor evasivo)
 * Modelo 3D, animación, disparo de flechas, navegación y audio espacial
 */

import * as THREE from 'three';
import { HealthSystem } from './HealthSystem';
import { StaminaSystem } from './StaminaSystem';
import { ArrowProjectile } from './ArrowProjectile';
import { PlayerRole, GameConfig } from '../types';
import { audioManager } from '../audio/AudioManager';

export class BotController {
  public mesh: THREE.Group;
  public position: THREE.Vector3;
  public velocity: THREE.Vector3;
  public healthSystem: HealthSystem;
  public staminaSystem: StaminaSystem;
  public role: PlayerRole = PlayerRole.RUNNER;
  public colliderBox: THREE.Box3;

  private walkSpeed: number = 4.4;
  private runSpeed: number = 8.2;
  private roleSwitchTime: number = 15;
  private difficulty: 'EASY' | 'MEDIUM' | 'HARD' = 'MEDIUM';

  // Componentes visuales del modelo 3D del bot
  private bodyMesh: THREE.Mesh;
  private headMesh: THREE.Mesh;
  private eyeLeft: THREE.Mesh;
  private eyeRight: THREE.Mesh;
  private bowMesh: THREE.Group;
  private auraLight: THREE.PointLight;

  // Estados de IA
  private stateTimer: number = 0;
  private shootCooldown: number = 2.0;
  private isChargingBow: boolean = false;
  private chargeTimer: number = 0;
  private targetPosition: THREE.Vector3 | null = null;
  private footstepTimer: number = 0;

  constructor(config: GameConfig, startPos: THREE.Vector3 = new THREE.Vector3(10, 0, 10)) {
    this.position = startPos.clone();
    this.velocity = new THREE.Vector3();
    this.healthSystem = new HealthSystem(config.playerMaxHealth);
    this.staminaSystem = new StaminaSystem(config.maxStamina, config.staminaDrainRate, config.staminaRecoveryRate);
    this.difficulty = config.botDifficulty;
    this.walkSpeed = config.playerWalkSpeed * 0.9;
    this.runSpeed = config.playerRunSpeed * 0.9;

    this.mesh = new THREE.Group();
    this.mesh.position.copy(this.position);

    // 1. Construcción del modelo 3D estilizado de rival
    // Torso
    const torsoGeo = new THREE.CylinderGeometry(0.35, 0.25, 0.9, 8);
    const torsoMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.7,
      metalness: 0.3,
    });
    this.bodyMesh = new THREE.Mesh(torsoGeo, torsoMat);
    this.bodyMesh.position.y = 0.95;
    this.bodyMesh.castShadow = true;
    this.mesh.add(this.bodyMesh);

    // Cabeza con capucha / máscara
    const headGeo = new THREE.SphereGeometry(0.24, 8, 8);
    const headMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.8,
    });
    this.headMesh = new THREE.Mesh(headGeo, headMat);
    this.headMesh.position.y = 1.6;
    this.headMesh.castShadow = true;
    this.mesh.add(this.headMesh);

    // Ojos brillantes (Rojos cuando es Cazador, Azules/Cian cuando es Corredor)
    const eyeGeo = new THREE.SphereGeometry(0.04, 6, 6);
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    this.eyeLeft = new THREE.Mesh(eyeGeo, eyeMat);
    this.eyeLeft.position.set(-0.09, 1.62, 0.2);
    this.eyeRight = new THREE.Mesh(eyeGeo, eyeMat);
    this.eyeRight.position.set(0.09, 1.62, 0.2);
    this.mesh.add(this.eyeLeft);
    this.mesh.add(this.eyeRight);

    // Luz ambiental que emite el bot (para ambientación en zonas oscuras)
    this.auraLight = new THREE.PointLight(0x06b6d4, 1.2, 5.0);
    this.auraLight.position.set(0, 1.4, 0);
    this.mesh.add(this.auraLight);

    // Arco en la espalda o mano
    this.bowMesh = this.createBotBow();
    this.bowMesh.position.set(0.3, 1.0, 0.2);
    this.mesh.add(this.bowMesh);

    this.colliderBox = new THREE.Box3();
    this.updateCollider();
  }

  private createBotBow(): THREE.Group {
    const group = new THREE.Group();
    const curvePoints: THREE.Vector3[] = [];
    for (let i = 0; i <= 10; i++) {
      const t = (i / 10) * Math.PI - Math.PI / 2;
      curvePoints.push(new THREE.Vector3(Math.cos(t) * 0.1, Math.sin(t) * 0.35, 0));
    }
    const curve = new THREE.CatmullRomCurve3(curvePoints);
    const tubeGeo = new THREE.TubeGeometry(curve, 10, 0.015, 6, false);
    const mat = new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.6 });
    const mesh = new THREE.Mesh(tubeGeo, mat);
    group.add(mesh);
    return group;
  }

  public setRole(role: PlayerRole) {
    this.role = role;
    this.isChargingBow = false;
    this.chargeTimer = 0;
    this.shootCooldown = 1.5;

    // Actualizar colores visuales del bot
    if (role === PlayerRole.HUNTER) {
      // Ojos y aura roja amenazante
      (this.eyeLeft.material as THREE.MeshBasicMaterial).color.setHex(0xef4444);
      (this.eyeRight.material as THREE.MeshBasicMaterial).color.setHex(0xef4444);
      this.auraLight.color.setHex(0xef4444);
      this.bowMesh.visible = true;
    } else {
      // Ojos y aura cian/azul evasivo
      (this.eyeLeft.material as THREE.MeshBasicMaterial).color.setHex(0x06b6d4);
      (this.eyeRight.material as THREE.MeshBasicMaterial).color.setHex(0x06b6d4);
      this.auraLight.color.setHex(0x06b6d4);
      this.bowMesh.visible = false;
    }
  }

  public update(
    delta: number,
    playerPos: THREE.Vector3,
    colliders: THREE.Box3[],
    onShootArrow?: (arrow: ArrowProjectile) => void
  ) {
    if (!this.healthSystem.isAlive()) {
      // Animación de derrota (caída al suelo)
      this.mesh.rotation.z = THREE.MathUtils.lerp(this.mesh.rotation.z, Math.PI / 2, 8 * delta);
      return;
    }

    this.healthSystem.update(delta);
    this.stateTimer += delta;

    // Distancia y vector hacia el jugador
    const toPlayer = playerPos.clone().sub(this.position);
    const distToPlayer = toPlayer.length();
    const dirToPlayer = toPlayer.clone().normalize();

    // 1. LÓGICA DE COMPORTAMIENTO SEGÚN ROL
    let desiredMove = new THREE.Vector3();
    let isSprinting = false;

    if (this.role === PlayerRole.HUNTER) {
      // CAZADOR: Perseguir al jugador y disparar con arco
      if (distToPlayer > 18) {
        // Lejos: Correr hacia el jugador
        desiredMove.copy(dirToPlayer).multiplyScalar(this.runSpeed);
        isSprinting = true;
      } else if (distToPlayer > 6) {
        // Rango medio de combate: Caminar y preparar tiro
        desiredMove.copy(dirToPlayer).multiplyScalar(this.walkSpeed);
      } else {
        // Muy cerca: Mantener distancia táctica para disparar
        desiredMove.copy(dirToPlayer).multiplyScalar(-this.walkSpeed * 0.5);
      }

      // Lógica de disparo con arco
      this.shootCooldown -= delta;
      if (this.shootCooldown <= 0 && distToPlayer < 24) {
        if (!this.isChargingBow) {
          this.isChargingBow = true;
          this.chargeTimer = 0;
        } else {
          this.chargeTimer += delta;
          const chargeTimeRequired = this.difficulty === 'HARD' ? 0.6 : this.difficulty === 'MEDIUM' ? 0.9 : 1.4;

          if (this.chargeTimer >= chargeTimeRequired) {
            // Disparar flecha hacia la posición estimada del jugador
            const shootPos = this.position.clone().add(new THREE.Vector3(0, 1.4, 0));
            // Predecir pequeña compensación de gravedad
            const shootDir = dirToPlayer.clone();
            shootDir.y += Math.min(0.25, distToPlayer * 0.015);
            shootDir.normalize();

            const arrow = new ArrowProjectile(
              shootPos,
              shootDir,
              34,
              45,
              false, // Disparada por el Bot
              9.8
            );

            audioManager.playBowRelease();
            if (onShootArrow) {
              onShootArrow(arrow);
            }

            this.isChargingBow = false;
            this.chargeTimer = 0;
            this.shootCooldown = this.difficulty === 'HARD' ? 1.8 : 2.5;
          }
        }
      }
    } else {
      // CORREDOR: Escapar, esconderse y usar esquinas
      if (distToPlayer < 14) {
        // Huir en dirección contraria
        desiredMove.copy(dirToPlayer).multiplyScalar(-this.runSpeed);
        isSprinting = true;
      } else {
        // Patrullar / buscar refugio
        if (!this.targetPosition || this.stateTimer > 4.0) {
          this.stateTimer = 0;
          this.targetPosition = this.position.clone().add(
            new THREE.Vector3((Math.random() - 0.5) * 16, 0, (Math.random() - 0.5) * 16)
          );
        }
        const toTarget = this.targetPosition.clone().sub(this.position);
        if (toTarget.length() > 1.0) {
          desiredMove.copy(toTarget.normalize()).multiplyScalar(this.walkSpeed);
        }
      }
    }

    // 2. Aplicar stamina y velocidad
    const { canSprint } = this.staminaSystem.update(delta, isSprinting, desiredMove.lengthSq() > 0.1);
    if (!canSprint && isSprinting) {
      desiredMove.normalize().multiplyScalar(this.walkSpeed);
    }

    // Aceleración
    this.velocity.x = THREE.MathUtils.lerp(this.velocity.x, desiredMove.x, 10 * delta);
    this.velocity.z = THREE.MathUtils.lerp(this.velocity.z, desiredMove.z, 10 * delta);

    // 3. Mover y Colisiones con muros
    const stepMove = this.velocity.clone().multiplyScalar(delta);
    this.position.x += stepMove.x;
    this.resolveCollisions(colliders, 'x');

    this.position.z += stepMove.z;
    this.resolveCollisions(colliders, 'z');

    this.mesh.position.copy(this.position);

    // Orientar modelo hacia la dirección de movimiento o hacia el jugador
    if (this.role === PlayerRole.HUNTER && distToPlayer < 20) {
      this.mesh.lookAt(playerPos.x, this.position.y, playerPos.z);
    } else if (this.velocity.lengthSq() > 0.1) {
      const lookTarget = this.position.clone().add(this.velocity);
      this.mesh.lookAt(lookTarget.x, this.position.y, lookTarget.z);
    }

    // 4. Sonidos de pasos espaciales (para que el jugador escuche dónde está el rival)
    if (desiredMove.lengthSq() > 0.1) {
      this.footstepTimer += delta;
      const stepInterval = isSprinting ? 0.3 : 0.48;
      if (this.footstepTimer >= stepInterval) {
        this.footstepTimer = 0;
        // Calcular pan estereofónico relativo al jugador
        const panX = THREE.MathUtils.clamp((this.position.x - playerPos.x) / 15, -1, 1);
        const distFactor = THREE.MathUtils.clamp(distToPlayer / 25, 0, 1);
        audioManager.playFootstep(isSprinting ? 'run' : 'walk', panX, distFactor);
      }
    }

    this.updateCollider();
  }

  private resolveCollisions(colliders: THREE.Box3[], axis: 'x' | 'z') {
    const radius = 0.45;
    const height = 1.8;
    const botBox = new THREE.Box3().setFromCenterAndSize(
      new THREE.Vector3(this.position.x, this.position.y + height / 2, this.position.z),
      new THREE.Vector3(radius * 2, height, radius * 2)
    );

    for (const box of colliders) {
      if (box.isEmpty()) continue;
      if (botBox.intersectsBox(box)) {
        if (axis === 'x') {
          const centerDistX = this.position.x - (box.min.x + box.max.x) / 2;
          this.position.x = centerDistX > 0 ? box.max.x + radius + 0.01 : box.min.x - radius - 0.01;
          this.velocity.x = 0;
        } else {
          const centerDistZ = this.position.z - (box.min.z + box.max.z) / 2;
          this.position.z = centerDistZ > 0 ? box.max.z + radius + 0.01 : box.min.z - radius - 0.01;
          this.velocity.z = 0;
        }
        botBox.setFromCenterAndSize(
          new THREE.Vector3(this.position.x, this.position.y + height / 2, this.position.z),
          new THREE.Vector3(radius * 2, height, radius * 2)
        );
      }
    }
  }

  private updateCollider() {
    this.colliderBox.setFromCenterAndSize(
      new THREE.Vector3(this.position.x, this.position.y + 0.9, this.position.z),
      new THREE.Vector3(0.9, 1.8, 0.9)
    );
  }

  public teleport(pos: THREE.Vector3) {
    this.position.copy(pos);
    this.mesh.position.copy(pos);
    this.velocity.set(0, 0, 0);
    this.updateCollider();
  }
}
