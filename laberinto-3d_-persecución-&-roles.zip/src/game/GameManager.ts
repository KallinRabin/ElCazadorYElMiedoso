/**
 * Motor Principal del Juego (GameManager)
 * Orquesta la Escena 3D de Three.js, Luces, Maze, Jugador, Bot Rival, Flechas,
 * Ciclo de Roles, Interacciones y Condiciones de Victoria.
 */

import * as THREE from 'three';
import { PlayerController } from './PlayerController';
import { BotController } from './BotController';
import { RoleManager } from './RoleManager';
import { MazeGenerator, MazeOutput } from './MazeGenerator';
import { ArrowProjectile } from './ArrowProjectile';
import { GameConfig, GameState, PlayerRole, WinConditionType, MatchStats, DEFAULT_CONFIG } from '../types';
import { audioManager } from '../audio/AudioManager';

export class GameManager {
  public scene: THREE.Scene;
  public renderer: THREE.WebGLRenderer | null = null;
  public player: PlayerController;
  public bot: BotController;
  public roleManager: RoleManager;
  public mazeData: MazeOutput | null = null;

  public config: GameConfig;
  public gameState: GameState = GameState.MENU;
  public activeArrows: ArrowProjectile[] = [];

  private animationFrameId: number | null = null;
  private lastTime: number = 0;
  private matchTimer: number = 0;
  private playerHits: number = 0;
  private botHits: number = 0;

  private onStateChangeCallbacks: Array<(state: GameState, stats: MatchStats) => void> = [];
  private onRoleAlertCallbacks: Array<(role: PlayerRole, message: string) => void> = [];
  private onHitEffectCallbacks: Array<(type: 'damage' | 'hit_target') => void> = [];

  constructor(config: GameConfig = DEFAULT_CONFIG) {
    this.config = { ...config };
    this.scene = new THREE.Scene();

    // Atmósfera oscura y tensa con niebla
    this.scene.background = new THREE.Color(0x0a0c10);
    this.scene.fog = new THREE.FogExp2(0x0a0c10, 0.045);

    // Iluminación ambiental limitada
    const ambientLight = new THREE.AmbientLight(0x222633, 0.65);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0x445577, 0.4);
    dirLight.position.set(20, 30, 15);
    this.scene.add(dirLight);

    this.roleManager = new RoleManager(this.config.roleSwitchTime, PlayerRole.HUNTER);
    this.player = new PlayerController(this.config);
    this.bot = new BotController(this.config);

    this.scene.add(this.player.rootObject);
    this.scene.add(this.bot.mesh);

    this.setupRoleListeners();
  }

  private setupRoleListeners() {
    this.roleManager.onRoleSwitch((playerRole, botRole, count) => {
      this.player.setRole(playerRole);
      this.bot.setRole(botRole);

      const msg = playerRole === PlayerRole.HUNTER
        ? '¡AHORA ERES EL CAZADOR! Tienes el arco listo.'
        : '¡AHORA ERES EL CORREDOR! Escóndete y huye.';

      this.onRoleAlertCallbacks.forEach(cb => cb(playerRole, msg));
    });

    // Daño a jugador
    this.player.healthSystem.onDamage((amount) => {
      this.botHits++;
      audioManager.playHurt();
      this.onHitEffectCallbacks.forEach(cb => cb('damage'));
      this.checkWinConditions();
    });

    this.player.healthSystem.onDeath(() => {
      this.endGame('BOT', 'El cazador rival te ha eliminado.');
    });

    // Daño a bot
    this.bot.healthSystem.onDamage((amount) => {
      this.playerHits++;
      this.onHitEffectCallbacks.forEach(cb => cb('hit_target'));
      this.checkWinConditions();
    });

    this.bot.healthSystem.onDeath(() => {
      this.endGame('PLAYER', '¡Has eliminado al corredor rival con tu flecha!');
    });
  }

  public initRenderer(container: HTMLCanvasElement) {
    if (this.renderer) {
      this.renderer.dispose();
    }

    this.renderer = new THREE.WebGLRenderer({
      canvas: container,
      antialias: true,
      powerPreference: 'high-performance',
    });

    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.player.cameraController.camera.aspect = window.innerWidth / window.innerHeight;
    this.player.cameraController.camera.updateProjectionMatrix();

    window.addEventListener('resize', this.onWindowResize);
  }

  private onWindowResize = () => {
    if (!this.renderer) return;
    const w = window.innerWidth;
    const h = window.innerHeight;
    this.renderer.setSize(w, h);
    this.player.cameraController.camera.aspect = w / h;
    this.player.cameraController.camera.updateProjectionMatrix();
  };

  public startMatch(config?: Partial<GameConfig>) {
    if (config) {
      this.config = { ...this.config, ...config };
      this.player.configure(this.config);
      this.roleManager.configure(this.config.roleSwitchTime);
    }

    // Inicializar audio
    audioManager.init();

    // 1. Limpiar laberinto previo
    if (this.mazeData) {
      this.scene.remove(this.mazeData.rootGroup);
    }

    // 2. Limpiar flechas
    this.activeArrows.forEach(a => this.scene.remove(a.mesh));
    this.activeArrows = [];

    // 3. Generar nuevo laberinto
    this.mazeData = MazeGenerator.generate(this.config.mazeSize, this.config.mazeSeed);
    this.scene.add(this.mazeData.rootGroup);

    // 4. Registrar objetos interactivos en el sistema de interacción
    this.player.interactionSystem.clear();
    this.mazeData.doors.forEach(door => this.player.interactionSystem.registerDoor(door));
    this.mazeData.passages.forEach(p => {
      this.player.interactionSystem.registerTrapdoor(p.entranceA, p);
      this.player.interactionSystem.registerTrapdoor(p.entranceB, p);
    });

    this.mazeData.arrowPickups.forEach(pickup => {
      this.player.interactionSystem.registerArrowPickup(pickup.id, pickup.mesh, () => {
        pickup.collected = true;
        pickup.mesh.visible = false;
        this.player.bowSystem.addArrows(5);
      });
    });

    // 5. Posicionar Jugador y Bot
    this.player.spawnAt(this.mazeData.playerSpawn);
    this.bot.teleport(this.mazeData.botSpawn);

    // 6. Resetear estados
    this.player.healthSystem.reset();
    this.player.staminaSystem.reset();
    this.player.bowSystem.arrowsCount = this.config.arrowInitialCount;

    this.bot.healthSystem.reset();
    this.bot.staminaSystem.reset();

    this.roleManager.reset(PlayerRole.HUNTER);
    this.player.setRole(PlayerRole.HUNTER);
    this.bot.setRole(PlayerRole.RUNNER);

    this.matchTimer = 0;
    this.playerHits = 0;
    this.botHits = 0;

    this.gameState = GameState.PLAYING;
    this.lastTime = performance.now();

    this.startLoop();
  }

  private startLoop() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }

    const loop = (currentTime: number) => {
      const delta = Math.min(0.06, (currentTime - this.lastTime) / 1000);
      this.lastTime = currentTime;

      if (this.gameState === GameState.PLAYING) {
        this.update(delta);
      }

      if (this.renderer && this.player) {
        this.renderer.render(this.scene, this.player.cameraController.camera);
      }

      this.animationFrameId = requestAnimationFrame(loop);
    };

    this.animationFrameId = requestAnimationFrame(loop);
  }

  private update(delta: number) {
    if (!this.mazeData) return;

    this.matchTimer += delta;

    // 1. Actualizar RoleManager
    this.roleManager.update(delta);

    // 2. Colisionadores combinados (Paredes + Puertas)
    const activeColliders = [...this.mazeData.colliders];
    this.mazeData.doors.forEach(d => {
      d.update(delta);
      if (!d.isOpen && !d.collider.isEmpty()) {
        activeColliders.push(d.collider);
      }
    });

    this.mazeData.passages.forEach(p => p.update(delta));

    // Parpadeo suave de antorchas
    const timeSec = performance.now() * 0.005;
    this.mazeData.torches.forEach((torch, i) => {
      torch.intensity = 1.4 + Math.sin(timeSec + i * 1.7) * 0.35 + Math.cos(timeSec * 2.3 + i) * 0.15;
    });

    // 3. Actualizar Jugador
    this.player.update(delta, activeColliders, this.mazeData.interactiveMeshes);

    // 4. Actualizar Bot IA
    this.bot.update(delta, this.player.movementController.position, activeColliders, (botArrow) => {
      this.scene.add(botArrow.mesh);
      this.activeArrows.push(botArrow);
    });

    // 5. Actualizar Flechas activas
    const hitTargets = [
      {
        id: 'PLAYER',
        box: this.player.movementController.getPlayerBoundingBox(),
        isPlayer: true,
        onHit: (dmg: number) => this.player.healthSystem.takeDamage(dmg),
      },
      {
        id: 'BOT',
        box: this.bot.colliderBox,
        isPlayer: false,
        onHit: (dmg: number) => this.bot.healthSystem.takeDamage(dmg),
      },
    ];

    for (let i = this.activeArrows.length - 1; i >= 0; i--) {
      const arrow = this.activeArrows[i];
      const alive = arrow.update(delta, activeColliders, hitTargets);
      if (arrow.isExpired || !alive) {
        this.scene.remove(arrow.mesh);
        this.activeArrows.splice(i, 1);
      }
    }

    // 6. Evaluar condiciones de victoria por tiempo
    this.checkWinConditions();
  }

  public shootPlayerArrow(arrow: ArrowProjectile) {
    this.scene.add(arrow.mesh);
    this.activeArrows.push(arrow);
  }

  private checkWinConditions() {
    if (this.gameState !== GameState.PLAYING) return;

    // Condición 1: Límite de tiempo
    if (this.config.matchTimeLimit > 0 && this.matchTimer >= this.config.matchTimeLimit) {
      if (this.playerHits > this.botHits) {
        this.endGame('PLAYER', '¡Tiempo concluido! Conseguiste mayor precisión de combate.');
      } else if (this.botHits > this.playerHits) {
        this.endGame('BOT', '¡Tiempo concluido! El rival infligió más daño.');
      } else {
        this.endGame('DRAW', '¡Tiempo concluido en empate técnico!');
      }
      return;
    }

    // Condición 2: Puntos de flechas
    if (this.config.winCondition === WinConditionType.ARROW_HITS) {
      if (this.playerHits >= this.config.targetScoreOrHits) {
        this.endGame('PLAYER', `¡Alcanzaste la meta de ${this.config.targetScoreOrHits} impactos con flechas!`);
      } else if (this.botHits >= this.config.targetScoreOrHits) {
        this.endGame('BOT', 'El rival alcanzó la meta de impactos primero.');
      }
    }
  }

  public endGame(winner: 'PLAYER' | 'BOT' | 'DRAW', reason: string) {
    this.gameState = GameState.GAME_OVER;
    if (winner === 'PLAYER') {
      audioManager.playVictory();
    } else {
      audioManager.playDefeat();
    }

    const stats = this.getMatchStats(winner, reason);
    this.onStateChangeCallbacks.forEach(cb => cb(this.gameState, stats));
  }

  public getMatchStats(winner: 'PLAYER' | 'BOT' | 'DRAW' | null = null, winReason: string = ''): MatchStats {
    return {
      elapsedTime: Math.floor(this.matchTimer),
      currentRoleTimer: this.roleManager.getTimeRemaining(),
      roleSwitchCount: this.roleManager.getSwitchCount(),
      playerRole: this.roleManager.getPlayerRole(),
      botRole: this.roleManager.getBotRole(),
      playerHits: this.playerHits,
      botHits: this.botHits,
      winner,
      winReason,
    };
  }

  public onStateChange(cb: (state: GameState, stats: MatchStats) => void) {
    this.onStateChangeCallbacks.push(cb);
  }

  public onRoleAlert(cb: (role: PlayerRole, message: string) => void) {
    this.onRoleAlertCallbacks.push(cb);
  }

  public onHitEffect(cb: (type: 'damage' | 'hit_target') => void) {
    this.onHitEffectCallbacks.push(cb);
  }

  public destroy() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    window.removeEventListener('resize', this.onWindowResize);
    if (this.renderer) {
      this.renderer.dispose();
    }
  }
}
