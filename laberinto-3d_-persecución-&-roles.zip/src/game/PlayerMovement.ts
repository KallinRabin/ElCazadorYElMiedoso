/**
 * Controlador de física y movimiento 3D del jugador
 * Maneja velocidad (caminar/correr/agacharse), salto, gravedad y colisiones de cápsula
 */

import * as THREE from 'three';
import { audioManager } from '../audio/AudioManager';

export class PlayerMovement {
  public position: THREE.Vector3;
  public velocity: THREE.Vector3;
  public isGrounded: boolean = true;
  public isCrouched: boolean = false;
  public isSprinting: boolean = false;
  public isMoving: boolean = false;

  private walkSpeed: number = 5.0;
  private runSpeed: number = 9.0;
  private crouchSpeed: number = 2.8;
  private jumpForce: number = 7.0;
  private gravity: number = 20.0;
  private playerRadius: number = 0.42;

  private footstepTimer: number = 0;

  constructor(
    startPos: THREE.Vector3 = new THREE.Vector3(0, 0, 0),
    walkSpeed: number = 5.0,
    runSpeed: number = 9.0,
    crouchSpeed: number = 2.8,
    jumpForce: number = 7.0
  ) {
    this.position = startPos.clone();
    this.velocity = new THREE.Vector3();
    this.walkSpeed = walkSpeed;
    this.runSpeed = runSpeed;
    this.crouchSpeed = crouchSpeed;
    this.jumpForce = jumpForce;
  }

  public configure(walkSpeed: number, runSpeed: number, crouchSpeed: number, jumpForce: number) {
    this.walkSpeed = walkSpeed;
    this.runSpeed = runSpeed;
    this.crouchSpeed = crouchSpeed;
    this.jumpForce = jumpForce;
  }

  public update(
    delta: number,
    inputDir: { forward: number; right: number },
    horizontalForward: THREE.Vector3,
    horizontalRight: THREE.Vector3,
    wantSprint: boolean,
    wantCrouch: boolean,
    wantJump: boolean,
    canSprintFromStamina: boolean,
    colliders: THREE.Box3[]
  ): { speed: number } {
    // 1. Determinar estado de agachado y velocidad objetivo
    this.isCrouched = wantCrouch;
    this.isSprinting = wantSprint && canSprintFromStamina && !this.isCrouched && (inputDir.forward > 0 || Math.abs(inputDir.right) > 0);

    let targetSpeed = this.walkSpeed;
    if (this.isCrouched) {
      targetSpeed = this.crouchSpeed;
    } else if (this.isSprinting) {
      targetSpeed = this.runSpeed;
    }

    // 2. Vector de dirección deseada en el plano XZ
    const moveDir = new THREE.Vector3()
      .addScaledVector(horizontalForward, inputDir.forward)
      .addScaledVector(horizontalRight, inputDir.right);

    if (moveDir.lengthSq() > 0.001) {
      moveDir.normalize();
      this.isMoving = true;
    } else {
      this.isMoving = false;
    }

    // Aceleración horizontal suave
    const targetVelX = moveDir.x * targetSpeed;
    const targetVelZ = moveDir.z * targetSpeed;
    const accelRate = this.isGrounded ? 16 : 6;

    this.velocity.x = THREE.MathUtils.lerp(this.velocity.x, targetVelX, accelRate * delta);
    this.velocity.z = THREE.MathUtils.lerp(this.velocity.z, targetVelZ, accelRate * delta);

    // 3. Salto y Gravedad
    if (this.isGrounded) {
      this.velocity.y = 0;
      if (wantJump && !this.isCrouched) {
        this.velocity.y = this.jumpForce;
        this.isGrounded = false;
        audioManager.playJump();
      }
    } else {
      this.velocity.y -= this.gravity * delta;
    }

    // 4. Mover y Resolver Colisiones
    const displacement = this.velocity.clone().multiplyScalar(delta);

    // Resolver X
    this.position.x += displacement.x;
    this.resolveWallCollisions(colliders, 'x');

    // Resolver Z
    this.position.z += displacement.z;
    this.resolveWallCollisions(colliders, 'z');

    // Resolver Y
    const wasGrounded = this.isGrounded;
    this.position.y += displacement.y;

    if (this.position.y <= 0) {
      this.position.y = 0;
      this.isGrounded = true;
      if (!wasGrounded) {
        audioManager.playLand();
      }
    } else {
      this.isGrounded = false;
    }

    // 5. Audio de pasos
    if (this.isGrounded && this.isMoving) {
      const stepInterval = this.isSprinting ? 0.28 : this.isCrouched ? 0.6 : 0.44;
      this.footstepTimer += delta;
      if (this.footstepTimer >= stepInterval) {
        this.footstepTimer = 0;
        audioManager.playFootstep(this.isSprinting ? 'run' : this.isCrouched ? 'crouch' : 'walk');
      }
    } else {
      this.footstepTimer = 0;
    }

    return {
      speed: new THREE.Vector2(this.velocity.x, this.velocity.z).length(),
    };
  }

  private resolveWallCollisions(colliders: THREE.Box3[], axis: 'x' | 'z') {
    const playerHeight = this.isCrouched ? 1.0 : 1.9;
    const playerBox = new THREE.Box3();

    playerBox.setFromCenterAndSize(
      new THREE.Vector3(this.position.x, this.position.y + playerHeight / 2, this.position.z),
      new THREE.Vector3(this.playerRadius * 2, playerHeight, this.playerRadius * 2)
    );

    for (const box of colliders) {
      if (box.isEmpty()) continue;

      if (playerBox.intersectsBox(box)) {
        // Separar eje
        if (axis === 'x') {
          const centerDistX = this.position.x - (box.min.x + box.max.x) / 2;
          if (centerDistX > 0) {
            this.position.x = box.max.x + this.playerRadius + 0.001;
          } else {
            this.position.x = box.min.x - this.playerRadius - 0.001;
          }
          this.velocity.x = 0;
        } else if (axis === 'z') {
          const centerDistZ = this.position.z - (box.min.z + box.max.z) / 2;
          if (centerDistZ > 0) {
            this.position.z = box.max.z + this.playerRadius + 0.001;
          } else {
            this.position.z = box.min.z - this.playerRadius - 0.001;
          }
          this.velocity.z = 0;
        }

        // Actualizar playerBox para siguientes colisiones
        playerBox.setFromCenterAndSize(
          new THREE.Vector3(this.position.x, this.position.y + playerHeight / 2, this.position.z),
          new THREE.Vector3(this.playerRadius * 2, playerHeight, this.playerRadius * 2)
        );
      }
    }
  }

  public teleport(newPos: THREE.Vector3) {
    this.position.copy(newPos);
    this.velocity.set(0, 0, 0);
  }

  public getPlayerBoundingBox(): THREE.Box3 {
    const height = this.isCrouched ? 1.0 : 1.9;
    return new THREE.Box3().setFromCenterAndSize(
      new THREE.Vector3(this.position.x, this.position.y + height / 2, this.position.z),
      new THREE.Vector3(0.8, height, 0.8)
    );
  }
}
