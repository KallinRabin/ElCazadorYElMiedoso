/**
 * Generador Procedural y Modular de Laberintos 3D con Semilla (Seed)
 * Construye pasillos, habitaciones, intersecciones, zonas bajas (crawling),
 * puertas interactivas, trampillas secretas, antorchas y plataformas elevadas.
 */

import * as THREE from 'three';
import { Door } from './Door';
import { Trapdoor } from './Trapdoor';
import { HiddenPassage } from './HiddenPassage';

export interface MazeOutput {
  rootGroup: THREE.Group;
  colliders: THREE.Box3[];
  doors: Door[];
  trapdoors: Trapdoor[];
  passages: HiddenPassage[];
  arrowPickups: Array<{ id: string; mesh: THREE.Group; position: THREE.Vector3; collected: boolean }>;
  playerSpawn: THREE.Vector3;
  botSpawn: THREE.Vector3;
  interactiveMeshes: THREE.Object3D[];
  torches: THREE.PointLight[];
  crawlSpaces: THREE.Box3[]; // Zonas bajas que requieren agacharse
}

// PRNG simple para reproducibilidad con semilla
class SeededRandom {
  private s: number;
  constructor(seed: number = 42) {
    this.s = seed % 2147483647;
    if (this.s <= 0) this.s += 2147483646;
  }
  public next(): number {
    this.s = (this.s * 16807) % 2147483647;
    return (this.s - 1) / 2147483646;
  }
  public range(min: number, max: number): number {
    return min + this.next() * (max - min);
  }
  public choice<T>(arr: T[]): T {
    return arr[Math.floor(this.next() * arr.length)];
  }
}

export class MazeGenerator {
  public static generate(size: number = 13, seed: number = 42): MazeOutput {
    const rng = new SeededRandom(seed);
    const cellSize = 4.0; // 4 metros por celda
    const wallHeight = 3.6; // Altura estándar de muros

    const rootGroup = new THREE.Group();
    rootGroup.name = 'MazeRoot';

    const colliders: THREE.Box3[] = [];
    const doors: Door[] = [];
    const trapdoors: Trapdoor[] = [];
    const passages: HiddenPassage[] = [];
    const arrowPickups: Array<{ id: string; mesh: THREE.Group; position: THREE.Vector3; collected: boolean }> = [];
    const interactiveMeshes: THREE.Object3D[] = [];
    const torches: THREE.PointLight[] = [];
    const crawlSpaces: THREE.Box3[] = [];

    // Materiales temáticos de mazmorra oscura
    const wallMat = new THREE.MeshStandardMaterial({
      color: 0x24272c,
      roughness: 0.85,
      metalness: 0.15,
    });
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x181a1e,
      roughness: 0.9,
      metalness: 0.1,
    });
    const ceilingMat = new THREE.MeshStandardMaterial({
      color: 0x121316,
      roughness: 0.95,
      metalness: 0.05,
    });
    const woodBeamMat = new THREE.MeshStandardMaterial({
      color: 0x3d2716,
      roughness: 0.8,
    });

    // 1. Crear matriz de grid (0: Pasillo, 1: Muro, 2: Habitación, 3: Zona baja crawl, 4: Puerta)
    // Inicializar todo como muro (1)
    const grid: number[][] = Array.from({ length: size }, () => Array(size).fill(1));

    // Generar laberinto usando DFS Backtracking
    function carvePassages(cx: number, cy: number) {
      grid[cy][cx] = 0;
      const dirs = [
        [0, -2], // Norte
        [2, 0],  // Este
        [0, 2],  // Sur
        [-2, 0], // Oeste
      ].sort(() => rng.next() - 0.5);

      for (const [dx, dy] of dirs) {
        const nx = cx + dx;
        const ny = cy + dy;
        if (nx > 0 && nx < size - 1 && ny > 0 && ny < size - 1 && grid[ny][nx] === 1) {
          grid[cy + dy / 2][cx + dx / 2] = 0;
          carvePassages(nx, ny);
        }
      }
    }

    carvePassages(1, 1);

    // 2. Crear Habitaciones Amplias y Especiales (Rooms)
    const center = Math.floor(size / 2);
    // Sala Central
    for (let dy = -1; dy <= 1; dy++) {
      for (let dx = -1; dx <= 1; dx++) {
        if (center + dy > 0 && center + dy < size - 1 && center + dx > 0 && center + dx < size - 1) {
          grid[center + dy][center + dx] = 2;
        }
      }
    }

    // Sala de Armería (esquina superior derecha)
    for (let dy = 1; dy <= 3; dy++) {
      for (let dx = size - 4; dx <= size - 2; dx++) {
        if (dy < size - 1 && dx > 0) grid[dy][dx] = 2;
      }
    }

    // Cripta / Sala de Altar (esquina inferior izquierda)
    for (let dy = size - 4; dy <= size - 2; dy++) {
      for (let dx = 1; dx <= 3; dx++) {
        if (dy > 0 && dx < size - 1) grid[dy][dx] = 2;
      }
    }

    // 3. Crear Zonas Bajas / Túneles de Gateo (Crawl spaces)
    // El jugador solo puede pasar agachado porque el techo baja a 1.4m
    const crawlX = Math.floor(size * 0.75);
    const crawlY = center;
    if (grid[crawlY] && grid[crawlY][crawlX] === 0) {
      grid[crawlY][crawlX] = 3; // Marcar como zona crawl
    }

    // 4. Crear Suelo y Techo Global
    const totalWorldSize = size * cellSize;
    const halfWorld = totalWorldSize / 2;

    const floorGeo = new THREE.PlaneGeometry(totalWorldSize + 8, totalWorldSize + 8);
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.position.set(0, 0, 0);
    floorMesh.receiveShadow = true;
    rootGroup.add(floorMesh);

    const ceilingGeo = new THREE.PlaneGeometry(totalWorldSize + 8, totalWorldSize + 8);
    const ceilingMesh = new THREE.Mesh(ceilingGeo, ceilingMat);
    ceilingMesh.rotation.x = Math.PI / 2;
    ceilingMesh.position.set(0, wallHeight, 0);
    rootGroup.add(ceilingMesh);

    // 5. Construir Muros y Celdas 3D
    const wallGeo = new THREE.BoxGeometry(cellSize, wallHeight, cellSize);
    const lowCeilingGeo = new THREE.BoxGeometry(cellSize, wallHeight - 1.4, cellSize);

    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const wx = (x - size / 2 + 0.5) * cellSize;
        const wz = (y - size / 2 + 0.5) * cellSize;
        const cell = grid[y][x];

        if (cell === 1) {
          // Muro sólido
          const wall = new THREE.Mesh(wallGeo, wallMat);
          wall.position.set(wx, wallHeight / 2, wz);
          wall.castShadow = true;
          wall.receiveShadow = true;
          rootGroup.add(wall);

          // Collider AABB para colisiones de movimiento y flechas
          const box = new THREE.Box3().setFromCenterAndSize(
            new THREE.Vector3(wx, wallHeight / 2, wz),
            new THREE.Vector3(cellSize, wallHeight, cellSize)
          );
          colliders.push(box);
        } else if (cell === 3) {
          // Túnel de gateo / Crawl space (bloque de techo bajo a 1.4m)
          const lowCeiling = new THREE.Mesh(lowCeilingGeo, woodBeamMat);
          lowCeiling.position.set(wx, 1.4 + (wallHeight - 1.4) / 2, wz);
          rootGroup.add(lowCeiling);

          const crawlBox = new THREE.Box3().setFromCenterAndSize(
            new THREE.Vector3(wx, 1.4 + (wallHeight - 1.4) / 2, wz),
            new THREE.Vector3(cellSize, wallHeight - 1.4, cellSize)
          );
          colliders.push(crawlBox);
          crawlSpaces.push(
            new THREE.Box3().setFromCenterAndSize(
              new THREE.Vector3(wx, 0.7, wz),
              new THREE.Vector3(cellSize, 1.4, cellSize)
            )
          );
        }

        // Colocar antorchas en pasillos periódicos y salas
        if ((cell === 0 || cell === 2) && (x + y * 3) % 7 === 0) {
          const torchLight = new THREE.PointLight(0xff7722, 1.6, 8.5);
          torchLight.position.set(wx, 2.2, wz);
          torchLight.castShadow = true;
          rootGroup.add(torchLight);
          torches.push(torchLight);

          // Modelo de antorcha en pared
          const torchHolderGeo = new THREE.CylinderGeometry(0.04, 0.03, 0.4, 6);
          const torchHolderMat = new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.8 });
          const torchHolder = new THREE.Mesh(torchHolderGeo, torchHolderMat);
          torchHolder.position.set(wx, 2.0, wz);
          rootGroup.add(torchHolder);

          const flameGeo = new THREE.SphereGeometry(0.08, 6, 6);
          const flameMat = new THREE.MeshBasicMaterial({ color: 0xffaa33 });
          const flame = new THREE.Mesh(flameGeo, flameMat);
          flame.position.set(wx, 2.25, wz);
          rootGroup.add(flame);
        }
      }
    }

    // 6. Colocar Puertas Interactivas en accesos clave
    // Puerta a la Sala Central
    const door1Pos = new THREE.Vector3((center - size / 2 + 0.5) * cellSize, 0, (center - 2 - size / 2 + 0.5) * cellSize);
    const door1 = new Door('door_center_north', door1Pos, 'horizontal', false);
    rootGroup.add(door1.group);
    doors.push(door1);
    interactiveMeshes.push(door1.group);

    // Puerta a la Armería
    const door2Pos = new THREE.Vector3((size - 4 - size / 2 + 0.5) * cellSize, 0, (2 - size / 2 + 0.5) * cellSize);
    const door2 = new Door('door_armory', door2Pos, 'vertical', false);
    rootGroup.add(door2.group);
    doors.push(door2);
    interactiveMeshes.push(door2.group);

    // Puerta a la Cripta
    const door3Pos = new THREE.Vector3((2 - size / 2 + 0.5) * cellSize, 0, (size - 4 - size / 2 + 0.5) * cellSize);
    const door3 = new Door('door_crypt', door3Pos, 'horizontal', false);
    rootGroup.add(door3.group);
    doors.push(door3);
    interactiveMeshes.push(door3.group);

    // 7. Colocar Trampillas y Pasadizos Secretos (HiddenPassage)
    // Conecta dos extremos distantes del mapa
    const trapPosA = new THREE.Vector3((2 - size / 2 + 0.5) * cellSize, 0.02, (2 - size / 2 + 0.5) * cellSize);
    const trapPosB = new THREE.Vector3((size - 3 - size / 2 + 0.5) * cellSize, 0.02, (size - 3 - size / 2 + 0.5) * cellSize);

    const trapdoorA = new Trapdoor('trap_secret_A', trapPosA, 'floor');
    const trapdoorB = new Trapdoor('trap_secret_B', trapPosB, 'floor');

    rootGroup.add(trapdoorA.group);
    rootGroup.add(trapdoorB.group);
    trapdoors.push(trapdoorA, trapdoorB);
    interactiveMeshes.push(trapdoorA.group, trapdoorB.group);

    const secretPassage = new HiddenPassage(
      'passage_diagonal_shortcut',
      trapdoorA,
      trapdoorB,
      trapPosA.clone().add(new THREE.Vector3(0, 0.5, 0)),
      trapPosB.clone().add(new THREE.Vector3(0, 0.5, 0))
    );
    passages.push(secretPassage);

    // 8. Colocar Paquetes de Flechas (Arrow Pickups) en el laberinto
    const arrowLocations = [
      new THREE.Vector3((size - 3 - size / 2 + 0.5) * cellSize, 0.5, (2 - size / 2 + 0.5) * cellSize), // En armería
      new THREE.Vector3((center - size / 2 + 0.5) * cellSize, 0.5, (center - size / 2 + 0.5) * cellSize), // En sala central
      new THREE.Vector3((2 - size / 2 + 0.5) * cellSize, 0.5, (size - 3 - size / 2 + 0.5) * cellSize), // En cripta
    ];

    arrowLocations.forEach((pos, idx) => {
      const pickupGroup = new THREE.Group();
      pickupGroup.position.copy(pos);

      // Carcaj / flechas agrupadas
      const quiverGeo = new THREE.CylinderGeometry(0.12, 0.1, 0.6, 8);
      const quiverMat = new THREE.MeshStandardMaterial({ color: 0x5c3317, roughness: 0.7 });
      const quiver = new THREE.Mesh(quiverGeo, quiverMat);
      quiver.rotation.z = 0.2;
      pickupGroup.add(quiver);

      const glowLight = new THREE.PointLight(0xffbb00, 1.2, 3.0);
      glowLight.position.set(0, 0.2, 0);
      pickupGroup.add(glowLight);

      pickupGroup.userData = { isArrowPickup: true, pickupId: `arrow_pickup_${idx}` };
      rootGroup.add(pickupGroup);

      arrowPickups.push({
        id: `arrow_pickup_${idx}`,
        mesh: pickupGroup,
        position: pos,
        collected: false,
      });
      interactiveMeshes.push(pickupGroup);
    });

    // 9. Puntos de Spawn tácticos para Jugador 1 y Bot
    const playerSpawn = new THREE.Vector3((1 - size / 2 + 0.5) * cellSize, 0.9, (1 - size / 2 + 0.5) * cellSize);
    const botSpawn = new THREE.Vector3((size - 2 - size / 2 + 0.5) * cellSize, 0.9, (size - 2 - size / 2 + 0.5) * cellSize);

    return {
      rootGroup,
      colliders,
      doors,
      trapdoors,
      passages,
      arrowPickups,
      playerSpawn,
      botSpawn,
      interactiveMeshes,
      torches,
      crawlSpaces,
    };
  }
}
