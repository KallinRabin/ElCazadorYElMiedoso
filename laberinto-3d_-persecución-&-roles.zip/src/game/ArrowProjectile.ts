/**
 * Proyectil Físico de Flecha
 * Incluye trayectoria balística con gravedad, colisión contra paredes, suelo, puertas y jugadores
 */

import * as THREE from 'three';
import { audioManager } from '../audio/AudioManager';

export class ArrowProjectile {
  public mesh: THREE.Group;
  public position: THREE.Vector3;
  public velocity: THREE.Vector3;
  public isStuck: boolean = false;
  public isExpired: boolean = false;
  public lifetime: number = 15; // Segundos antes de desaparecer si queda clavada
  public ownerIsPlayer: boolean;
  public damage: number = 50;

  private gravity: number = 9.8;
  private previousPosition: THREE.Vector3;
  private stuckTime: number = 0;

  constructor(
    startPos: THREE.Vector3,
    direction: THREE.Vector3,
    speed: number = 36,
    damage: number = 50,
    ownerIsPlayer: boolean = true,
    gravity: number = 9.8
  ) {
    this.position = startPos.clone();
    this.previousPosition = startPos.clone();
    this.velocity = direction.clone().normalize().multiplyScalar(speed);
    this.damage = damage;
    this.ownerIsPlayer = ownerIsPlayer;
    this.gravity = gravity;

    this.mesh = new THREE.Group();
    this.mesh.position.copy(this.position);

    // Eje de la flecha (madera oscura)
    const shaftGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.8, 8);
    const shaftMat = new THREE.MeshStandardMaterial({ color: 0x8b5a2b, roughness: 0.8 });
    const shaft = new THREE.Mesh(shaftGeo, shaftMat);
    shaft.rotation.x = Math.PI / 2; // Apunta a lo largo del eje Z
    this.mesh.add(shaft);

    // Punta metálica afilada (cono)
    const tipGeo = new THREE.ConeGeometry(0.04, 0.15, 8);
    const tipMat = new THREE.MeshStandardMaterial({ color: 0xdddddd, metalness: 0.9, roughness: 0.2 });
    const tip = new THREE.Mesh(tipGeo, tipMat);
    tip.rotation.x = -Math.PI / 2;
    tip.position.z = 0.45;
    this.mesh.add(tip);

    // Plumas traseras (Fletching rojo/blanco para visibilidad táctica)
    const featherGeo = new THREE.BoxGeometry(0.005, 0.08, 0.18);
    const featherMat = new THREE.MeshStandardMaterial({
      color: ownerIsPlayer ? 0xef4444 : 0x3b82f6,
      roughness: 0.4,
    });
    const f1 = new THREE.Mesh(featherGeo, featherMat);
    f1.position.z = -0.32;
    const f2 = f1.clone();
    f2.rotation.z = Math.PI / 2;
    this.mesh.add(f1);
    this.mesh.add(f2);

    // Pequeño rastro de luz de la flecha
    const trailLight = new THREE.PointLight(ownerIsPlayer ? 0xff4422 : 0x2288ff, 0.8, 2.0);
    this.mesh.add(trailLight);

    // Orientar flecha en la dirección inicial
    this.alignWithVelocity();
  }

  private alignWithVelocity() {
    if (this.velocity.lengthSq() > 0.001) {
      const dir = this.velocity.clone().normalize();
      const targetPos = this.position.clone().add(dir);
      this.mesh.lookAt(targetPos);
    }
  }

  public update(
    delta: number,
    colliders: THREE.Box3[],
    targets: Array<{ id: string; box: THREE.Box3; isPlayer: boolean; onHit: (dmg: number) => void }>
  ): boolean {
    if (this.isExpired) return false;

    if (this.isStuck) {
      this.stuckTime += delta;
      if (this.stuckTime >= this.lifetime) {
        this.isExpired = true;
      }
      return true;
    }

    this.previousPosition.copy(this.position);

    // Aplicar gravedad balística
    this.velocity.y -= this.gravity * delta;

    // Calcular desplazamiento
    const stepMove = this.velocity.clone().multiplyScalar(delta);
    const nextPos = this.position.clone().add(stepMove);

    // Rayo continuo desde previousPosition hasta nextPos para no atravesar muros finos
    const moveDir = nextPos.clone().sub(this.previousPosition);
    const moveDist = moveDir.length();
    if (moveDist > 0.0001) {
      const ray = new THREE.Ray(this.previousPosition, moveDir.clone().normalize());

      // 1. Chequeo contra objetivos (Jugador / Bot)
      for (const target of targets) {
        // No auto-dañarse
        if (target.isPlayer === this.ownerIsPlayer) continue;

        const intersect = ray.intersectBox(target.box, new THREE.Vector3());
        if (intersect && intersect.distanceTo(this.previousPosition) <= moveDist) {
          // Impacto en jugador / bot
          this.position.copy(intersect);
          this.mesh.position.copy(this.position);
          this.isStuck = true;
          this.lifetime = 2.0; // Desaparece antes
          target.onHit(this.damage);
          audioManager.playArrowHit('flesh');
          return true;
        }
      }

      // 2. Chequeo contra colisionadores de entorno (Paredes, suelo, puertas)
      let closestHitDist = moveDist;
      let hitPoint: THREE.Vector3 | null = null;

      for (const box of colliders) {
        const hit = ray.intersectBox(box, new THREE.Vector3());
        if (hit) {
          const d = hit.distanceTo(this.previousPosition);
          if (d < closestHitDist) {
            closestHitDist = d;
            hitPoint = hit;
          }
        }
      }

      // Chequeo con suelo plano y=0
      if (nextPos.y <= 0.05) {
        this.position.y = 0.05;
        this.isStuck = true;
        this.mesh.position.copy(this.position);
        audioManager.playArrowHit('wall');
        return true;
      }

      if (hitPoint) {
        this.position.copy(hitPoint);
        this.mesh.position.copy(this.position);
        this.isStuck = true;
        audioManager.playArrowHit('wood');
        return true;
      }
    }

    this.position.copy(nextPos);
    this.mesh.position.copy(this.position);
    this.alignWithVelocity();

    return true;
  }
}
