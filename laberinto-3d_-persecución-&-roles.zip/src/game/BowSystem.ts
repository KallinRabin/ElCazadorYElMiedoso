/**
 * Sistema de combate con Arco y Flechas
 * Controla la carga, animación de tensado de cuerda, recarga y disparo de proyectiles
 */

import * as THREE from 'three';
import { ArrowProjectile } from './ArrowProjectile';
import { audioManager } from '../audio/AudioManager';

export class BowSystem {
  public viewModel: THREE.Group;
  public bowMesh: THREE.Group;
  public stringLine: THREE.Line;
  public arrowMeshInBow: THREE.Group;

  public isCharging: boolean = false;
  public chargeProgress: number = 0; // 0 a 1
  public reloadTimer: number = 0;
  public arrowsCount: number = 8;
  public maxArrows: number = 20;

  private reloadDuration: number = 1.2;
  private arrowDamage: number = 50;
  private arrowSpeed: number = 38;
  private arrowGravity: number = 9.8;
  private chargeSpeed: number = 1.6; // ~0.625s para carga completa
  private isEquipped: boolean = false;

  // Puntos de la cuerda del arco
  private stringPositions: Float32Array;

  constructor(reloadDuration: number = 1.2, arrowDamage: number = 50, initialArrows: number = 8) {
    this.reloadDuration = reloadDuration;
    this.arrowDamage = damageFallback(arrowDamage);
    this.arrowsCount = initialArrows;

    this.viewModel = new THREE.Group();
    this.bowMesh = new THREE.Group();

    // Crear modelo procedural del arco
    this.buildBowModel();
  }

  public configure(reloadDuration: number, arrowDamage: number, arrowSpeed: number = 38, arrowGravity: number = 9.8) {
    this.reloadDuration = reloadDuration;
    this.arrowDamage = damageFallback(arrowDamage);
    this.arrowSpeed = arrowSpeed;
    this.arrowGravity = arrowGravity;
  }

  private buildBowModel() {
    // Curva del arco (pala superior e inferior)
    const curvePoints: THREE.Vector3[] = [];
    const segments = 16;
    for (let i = 0; i <= segments; i++) {
      const t = (i / segments) * Math.PI - Math.PI / 2;
      const x = Math.cos(t) * 0.15;
      const y = Math.sin(t) * 0.45;
      curvePoints.push(new THREE.Vector3(x, y, 0));
    }

    const curve = new THREE.CatmullRomCurve3(curvePoints);
    const tubeGeo = new THREE.TubeGeometry(curve, 20, 0.018, 8, false);
    const bowMat = new THREE.MeshStandardMaterial({
      color: 0x3d2314,
      roughness: 0.6,
      metalness: 0.2,
    });
    const woodBody = new THREE.Mesh(tubeGeo, bowMat);
    this.bowMesh.add(woodBody);

    // Empuñadura de cuero en el centro
    const gripGeo = new THREE.CylinderGeometry(0.024, 0.024, 0.14, 8);
    const gripMat = new THREE.MeshStandardMaterial({ color: 0x1c120c, roughness: 0.9 });
    const grip = new THREE.Mesh(gripGeo, gripMat);
    grip.position.set(0.14, 0, 0);
    this.bowMesh.add(grip);

    // Cuerda del arco (Línea de 3 puntos: punta superior, punto de tiro, punta inferior)
    this.stringPositions = new Float32Array([
      0.0, 0.45, 0,    // Top tip
      0.14, 0.0, 0,    // Nock point (centro tirado hacia atrás en Z)
      0.0, -0.45, 0    // Bottom tip
    ]);
    const stringGeo = new THREE.BufferGeometry();
    stringGeo.setAttribute('position', new THREE.BufferAttribute(this.stringPositions, 3));
    const stringMat = new THREE.LineBasicMaterial({ color: 0xffffff, linewidth: 2 });
    this.stringLine = new THREE.Line(stringGeo, stringMat);
    this.bowMesh.add(this.stringLine);

    // Flecha cargada en el arco (visible mientras apunta)
    this.arrowMeshInBow = new THREE.Group();
    const shaftGeo = new THREE.CylinderGeometry(0.008, 0.008, 0.7, 6);
    const shaftMat = new THREE.MeshStandardMaterial({ color: 0xa06535 });
    const shaft = new THREE.Mesh(shaftGeo, shaftMat);
    shaft.rotation.x = Math.PI / 2;
    this.arrowMeshInBow.add(shaft);

    const tipGeo = new THREE.ConeGeometry(0.02, 0.08, 6);
    const tipMat = new THREE.MeshStandardMaterial({ color: 0xcccccc, metalness: 0.8 });
    const tip = new THREE.Mesh(tipGeo, tipMat);
    tip.rotation.x = -Math.PI / 2;
    tip.position.z = 0.38;
    this.arrowMeshInBow.add(tip);

    const featherGeo = new THREE.BoxGeometry(0.004, 0.04, 0.1);
    const featherMat = new THREE.MeshStandardMaterial({ color: 0xef4444 });
    const f1 = new THREE.Mesh(featherGeo, featherMat);
    f1.position.z = -0.28;
    this.arrowMeshInBow.add(f1);

    this.arrowMeshInBow.position.set(0.14, 0, 0);
    this.bowMesh.add(this.arrowMeshInBow);

    // Posicionamiento de vista en primera persona (abajo a la derecha)
    this.bowMesh.position.set(0.28, -0.25, -0.45);
    this.bowMesh.rotation.set(0.1, -0.2, -0.05);

    this.viewModel.add(this.bowMesh);
  }

  public setEquipped(equipped: boolean) {
    this.isEquipped = equipped;
    this.viewModel.visible = equipped;
    if (!equipped && this.isCharging) {
      this.cancelCharge();
    }
  }

  public startCharging(): boolean {
    if (!this.isEquipped || this.reloadTimer > 0 || this.arrowsCount <= 0) {
      return false;
    }
    this.isCharging = true;
    this.chargeProgress = 0;
    audioManager.startBowDraw();
    return true;
  }

  public cancelCharge() {
    this.isCharging = false;
    this.chargeProgress = 0;
    audioManager.stopBowDraw();
    this.updateStringGeometry(0);
  }

  public releaseAndShoot(
    spawnPos: THREE.Vector3,
    direction: THREE.Vector3,
    ownerIsPlayer: boolean = true
  ): ArrowProjectile | null {
    if (!this.isCharging) return null;

    const actualCharge = Math.max(0.3, this.chargeProgress);
    this.isCharging = false;
    this.chargeProgress = 0;
    this.updateStringGeometry(0);

    if (this.arrowsCount <= 0) {
      audioManager.stopBowDraw();
      return null;
    }

    this.arrowsCount--;
    this.reloadTimer = this.reloadDuration;

    audioManager.playBowRelease();

    // Calcular velocidad basada en el tiempo de carga
    const effectiveSpeed = this.arrowSpeed * (0.6 + 0.4 * actualCharge);
    const effectiveDamage = Math.round(this.arrowDamage * (0.5 + 0.5 * actualCharge));

    return new ArrowProjectile(
      spawnPos,
      direction,
      effectiveSpeed,
      effectiveDamage,
      ownerIsPlayer,
      this.arrowGravity
    );
  }

  public addArrows(count: number) {
    this.arrowsCount = Math.min(this.maxArrows, this.arrowsCount + count);
    audioManager.playPickup();
  }

  public update(delta: number) {
    if (this.reloadTimer > 0) {
      this.reloadTimer -= delta;
      if (this.reloadTimer < 0) this.reloadTimer = 0;
    }

    if (this.isCharging) {
      this.chargeProgress = Math.min(1.0, this.chargeProgress + this.chargeSpeed * delta);
      this.updateStringGeometry(this.chargeProgress);

      // Desplazar ligeramente el arco hacia el centro de la pantalla al apuntar
      const targetX = 0.05 + (1 - this.chargeProgress) * 0.23;
      const targetY = -0.15 + (1 - this.chargeProgress) * -0.1;
      const targetZ = -0.38 + this.chargeProgress * 0.05;
      this.bowMesh.position.lerp(new THREE.Vector3(targetX, targetY, targetZ), 12 * delta);
      this.arrowMeshInBow.visible = true;
    } else {
      // Retornar a reposo
      this.bowMesh.position.lerp(new THREE.Vector3(0.28, -0.25, -0.45), 10 * delta);
      this.arrowMeshInBow.visible = this.reloadTimer === 0 && this.arrowsCount > 0;
    }
  }

  private updateStringGeometry(charge: number) {
    if (!this.stringLine || !this.stringPositions) return;

    // Desplazar punto central de la cuerda hacia atrás en Z
    const pullBack = charge * 0.22;
    this.stringPositions[3] = 0.14;       // X
    this.stringPositions[4] = 0.0;        // Y
    this.stringPositions[5] = -pullBack;  // Z

    const posAttr = this.stringLine.geometry.getAttribute('position') as THREE.BufferAttribute;
    posAttr.copyArray(this.stringPositions);
    posAttr.needsUpdate = true;

    // Acompañar flecha con la cuerda
    this.arrowMeshInBow.position.z = -pullBack;
  }

  public getCanShoot(): boolean {
    return this.isEquipped && this.reloadTimer === 0 && this.arrowsCount > 0;
  }

  public getReloadProgress(): number {
    return this.reloadDuration > 0 ? (this.reloadDuration - this.reloadTimer) / this.reloadDuration : 1;
  }
}

function damageFallback(val: number): number {
  return typeof val === 'number' && !isNaN(val) ? val : 50;
}
