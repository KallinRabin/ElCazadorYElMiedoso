/**
 * Modal de Fin de Partida (Victoria / Derrota)
 */

import React, { useEffect } from 'react';
import { MatchStats } from '../types';
import confetti from 'canvas-confetti';
import { Trophy, Skull, RotateCcw, Home, Clock, Target, Activity } from 'lucide-react';

interface GameOverModalProps {
  stats: MatchStats | null;
  onRematch: () => void;
  onReturnToMenu: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({ stats, onRematch, onReturnToMenu }) => {
  if (!stats || !stats.winner) return null;

  const isPlayerWinner = stats.winner === 'PLAYER';

  useEffect(() => {
    if (isPlayerWinner) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {}
    }
  }, [isPlayerWinner]);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 md:p-8 flex flex-col items-center text-center shadow-2xl text-slate-100 animate-in fade-in zoom-in duration-300">
        {/* Icono de Resultado */}
        <div
          className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 shadow-xl ${
            isPlayerWinner
              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40 shadow-amber-500/20'
              : 'bg-rose-500/20 text-rose-400 border border-rose-500/40 shadow-rose-500/20'
          }`}
        >
          {isPlayerWinner ? <Trophy className="w-10 h-10" /> : <Skull className="w-10 h-10" />}
        </div>

        {/* Título de Resultado */}
        <h2 className="text-2xl md:text-3xl font-black tracking-tight text-white mb-1">
          {isPlayerWinner ? '¡VICTORIA!' : 'DERROTA'}
        </h2>
        <p className="text-sm text-slate-400 mb-6">{stats.winReason}</p>

        {/* Estadísticas de la Partida */}
        <div className="w-full grid grid-cols-3 gap-2.5 bg-slate-950/60 p-4 rounded-2xl border border-slate-800/80 mb-6 text-left">
          <div className="flex flex-col gap-1">
            <span className="text-[11px] text-slate-400 flex items-center gap-1 font-semibold">
              <Clock className="w-3 h-3 text-slate-400" />
              Tiempo
            </span>
            <span className="font-mono text-sm font-bold text-slate-200">{stats.elapsedTime}s</span>
          </div>

          <div className="flex flex-col gap-1">
            <span className="text-[11px] text-slate-400 flex items-center gap-1 font-semibold">
              <Activity className="w-3 h-3 text-amber-400" />
              Cambios Rol
            </span>
            <span className="font-mono text-sm font-bold text-amber-400">{stats.roleSwitchCount}</span>
          </div>

          <div className="flex flex-col gap-1">
            <span className="text-[11px] text-slate-400 flex items-center gap-1 font-semibold">
              <Target className="w-3 h-3 text-rose-400" />
              Impactos
            </span>
            <span className="font-mono text-sm font-bold text-slate-200">
              {stats.playerHits} vs {stats.botHits}
            </span>
          </div>
        </div>

        {/* Botones de Acción */}
        <div className="w-full flex gap-3">
          <button
            onClick={onReturnToMenu}
            className="flex-1 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Home className="w-4 h-4" />
            Menú Principal
          </button>
          <button
            onClick={onRematch}
            className="flex-1 py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center gap-2 transition-all shadow-lg shadow-amber-500/20 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            Revancha
          </button>
        </div>
      </div>
    </div>
  );
};
