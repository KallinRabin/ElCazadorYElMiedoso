/**
 * Pantalla de Inicio / Menú Principal del Juego
 */

import React from 'react';
import { GameConfig, WinConditionType } from '../types';
import { Play, Settings, Compass, Shield, Target, Key, Zap, Volume2, Sparkles } from 'lucide-react';

interface StartScreenProps {
  config: GameConfig;
  onStartMatch: (customConfig?: Partial<GameConfig>) => void;
  onOpenSettings: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({ config, onStartMatch, onOpenSettings }) => {
  const [seed, setSeed] = React.useState(config.mazeSeed);
  const [switchTime, setSwitchTime] = React.useState(config.roleSwitchTime);
  const [winCondition, setWinCondition] = React.useState<WinConditionType>(config.winCondition);
  const [botDifficulty, setBotDifficulty] = React.useState(config.botDifficulty);

  const handleLaunch = () => {
    onStartMatch({
      mazeSeed: seed,
      roleSwitchTime: switchTime,
      winCondition,
      botDifficulty,
    });
  };

  const handleRandomSeed = () => {
    setSeed(Math.floor(Math.random() * 999999));
  };

  return (
    <div className="absolute inset-0 z-30 bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4 md:p-8 overflow-y-auto">
      <div className="max-w-3xl w-full bg-slate-900/90 border border-slate-800 rounded-3xl p-6 md:p-10 shadow-2xl flex flex-col gap-6 text-slate-100 animate-in fade-in zoom-in duration-300">
        {/* Encabezado */}
        <div className="text-center flex flex-col items-center gap-2">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            Supervivencia &amp; Persecución 3D
          </div>
          <h1 className="text-3xl md:text-5xl font-black tracking-tight text-white mt-1">
            LABERINTO <span className="text-amber-500">3D</span>
          </h1>
          <p className="text-slate-400 text-sm md:text-base max-w-xl">
            Dos jugadores atrapados en un laberinto modular oscuro. Los roles de <span className="text-amber-400 font-semibold">Cazador</span> y <span className="text-cyan-400 font-semibold">Corredor</span> se intercambian automáticamente cada <span className="text-amber-400 font-bold">{switchTime} segundos</span>.
          </p>
        </div>

        {/* Resumen de Reglas Clave */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="bg-slate-950/60 border border-slate-800 p-3.5 rounded-2xl flex flex-col gap-1.5">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase">
              <Target className="w-4 h-4" />
              Cazador (Arco)
            </div>
            <p className="text-xs text-slate-400">
              Mantén Click Izquierdo para tensar el arco y suelta para disparar flechas físicas con parábola.
            </p>
          </div>

          <div className="bg-slate-950/60 border border-slate-800 p-3.5 rounded-2xl flex flex-col gap-1.5">
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs uppercase">
              <Shield className="w-4 h-4" />
              Corredor (Evasión)
            </div>
            <p className="text-xs text-slate-400">
              Usa pasadizos secretos, trampillas y agáchate con [C]/[Ctrl] para cruzar zonas bajas y túneles.
            </p>
          </div>

          <div className="bg-slate-950/60 border border-slate-800 p-3.5 rounded-2xl flex flex-col gap-1.5">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase">
              <Zap className="w-4 h-4" />
              Stamina &amp; Entorno
            </div>
            <p className="text-xs text-slate-400">
              Gestiona el sprint con [Shift]. Interactúa con [E] para abrir/cerrar puertas y activar atajos.
            </p>
          </div>
        </div>

        {/* Configuración Rápida de Partida */}
        <div className="bg-slate-950/50 border border-slate-800/80 p-5 rounded-2xl flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">Ajustes Rápidos</span>
            <button
              onClick={onOpenSettings}
              className="text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Settings className="w-3.5 h-3.5" />
              Configuración Avanzada
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Tiempo de Intercambio */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs text-slate-400">Tiempo de Cambio:</label>
              <select
                value={switchTime}
                onChange={(e) => setSwitchTime(Number(e.target.value))}
                className="bg-slate-900 border border-slate-700 text-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-amber-500 font-semibold"
              >
                <option value={10}>10 segundos (Frenético)</option>
                <option value={15}>15 segundos (Estándar)</option>
                <option value={20}>20 segundos (Táctico)</option>
                <option value={30}>30 segundos (Largo)</option>
              </select>
            </div>

            {/* Dificultad del Bot */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs text-slate-400">Oponente IA:</label>
              <select
                value={botDifficulty}
                onChange={(e) => setBotDifficulty(e.target.value as 'EASY' | 'MEDIUM' | 'HARD')}
                className="bg-slate-900 border border-slate-700 text-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-amber-500 font-semibold"
              >
                <option value="EASY">Fácil (Principiante)</option>
                <option value="MEDIUM">Medio (Desafiante)</option>
                <option value="HARD">Difícil (Experto)</option>
              </select>
            </div>

            {/* Semilla de Laberinto */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs text-slate-400">Semilla Laberinto:</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  value={seed}
                  onChange={(e) => setSeed(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-amber-500 font-mono"
                />
                <button
                  type="button"
                  onClick={handleRandomSeed}
                  title="Generar semilla aleatoria"
                  className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-2 rounded-xl text-xs font-semibold transition-colors"
                >
                  🎲
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Botón de Inicio */}
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between pt-2">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <Key className="w-4 h-4 text-slate-500" />
            <span>Al hacer click se activará el control de ratón (Pointer Lock)</span>
          </div>

          <button
            onClick={handleLaunch}
            className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-base rounded-2xl shadow-xl shadow-amber-500/20 hover:shadow-amber-500/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-slate-950" />
            INICIAR PARTIDA
          </button>
        </div>
      </div>
    </div>
  );
};
