/**
 * HUD principal del juego en primera persona
 * Muestra Rol actual, Temporizador de cambio de rol, Barra de Stamina, Salud, Flechas e Interacción
 */

import React, { useState, useEffect } from 'react';
import { PlayerStats, MatchStats, PlayerRole } from '../types';
import { Shield, Target, Crosshair, Zap, Heart, AlertTriangle, Key } from 'lucide-react';

interface HUDProps {
  playerStats: PlayerStats | null;
  matchStats: MatchStats | null;
  interactionPrompt: string | null;
  roleAlert: { role: PlayerRole; message: string } | null;
  damageFlash: boolean;
  hitMarker: boolean;
  onOpenSettings: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  playerStats,
  matchStats,
  interactionPrompt,
  roleAlert,
  damageFlash,
  hitMarker,
  onOpenSettings,
}) => {
  if (!playerStats || !matchStats) return null;

  const isHunter = playerStats.role === PlayerRole.HUNTER;
  const timer = Math.ceil(matchStats.currentRoleTimer);
  const isTimerCritical = timer <= 4;
  const staminaPercent = Math.max(0, Math.min(100, (playerStats.stamina / playerStats.maxStamina) * 100));
  const healthPercent = Math.max(0, Math.min(100, (playerStats.health / playerStats.maxHealth) * 100));

  return (
    <div id="game-hud" className="absolute inset-0 pointer-events-none select-none flex flex-col justify-between p-6 z-20">
      {/* 1. EFECTOS DE PANTALLA (Daño y Hit Marker) */}
      {damageFlash && (
        <div className="absolute inset-0 bg-red-600/35 animate-pulse pointer-events-none transition-opacity duration-150" />
      )}

      {/* 2. PARTE SUPERIOR: TEMPORIZADOR DE CAMBIO DE ROL */}
      <div className="w-full flex flex-col items-center justify-start gap-2">
        <div
          className={`flex items-center gap-3 px-6 py-2.5 rounded-full border backdrop-blur-md transition-all duration-300 shadow-2xl ${
            isTimerCritical
              ? 'bg-red-950/80 border-red-500 text-red-100 scale-105 animate-bounce shadow-red-900/50'
              : 'bg-slate-900/80 border-slate-700/80 text-slate-100'
          }`}
        >
          <div className={`w-3 h-3 rounded-full ${isTimerCritical ? 'bg-red-500 animate-ping' : 'bg-amber-400'}`} />
          <span className="text-xs md:text-sm font-semibold tracking-wider uppercase text-slate-300">
            Cambio de Rol en:
          </span>
          <span
            className={`font-mono text-xl md:text-2xl font-black px-2 py-0.5 rounded ${
              isTimerCritical ? 'text-red-400 bg-red-950/90' : 'text-amber-400 bg-slate-800/80'
            }`}
          >
            {timer < 10 ? `0${timer}` : timer}s
          </span>
        </div>

        {/* Notificación cinemática de cambio de rol */}
        {roleAlert && (
          <div
            className={`mt-3 px-6 py-2.5 rounded-xl border backdrop-blur-lg animate-in fade-in zoom-in duration-300 shadow-2xl flex items-center gap-3 ${
              roleAlert.role === PlayerRole.HUNTER
                ? 'bg-amber-950/90 border-amber-500 text-amber-100'
                : 'bg-cyan-950/90 border-cyan-500 text-cyan-100'
            }`}
          >
            {roleAlert.role === PlayerRole.HUNTER ? (
              <Target className="w-6 h-6 text-amber-400 animate-spin" />
            ) : (
              <Shield className="w-6 h-6 text-cyan-400 animate-pulse" />
            )}
            <span className="font-bold text-sm md:text-base tracking-wide">{roleAlert.message}</span>
          </div>
        )}
      </div>

      {/* 3. CENTRO: RETÍCULA DINÁMICA & PROMPT DE INTERACCIÓN */}
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        {/* Crosshair */}
        <div className="relative flex items-center justify-center">
          {hitMarker && (
            <div className="absolute w-8 h-8 border-2 border-red-500 rotate-45 animate-ping opacity-90" />
          )}

          {isHunter ? (
            // Retícula de tiro con arco
            <div
              className={`relative transition-all duration-100 ${
                playerStats.isChargingBow ? 'scale-75 rotate-45' : 'scale-100'
              }`}
            >
              <div className="w-1.5 h-1.5 bg-amber-400 rounded-full shadow-[0_0_8px_rgba(251,191,36,0.9)]" />
              {/* Anillo de carga de flecha */}
              {playerStats.isChargingBow && (
                <svg className="absolute -top-4 -left-4 w-9 h-9 -rotate-90">
                  <circle cx="18" cy="18" r="14" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="2" />
                  <circle
                    cx="18"
                    cy="18"
                    r="14"
                    fill="none"
                    stroke="#f59e0b"
                    strokeWidth="3"
                    strokeDasharray={88}
                    strokeDashoffset={88 - 88 * playerStats.bowChargeProgress}
                    strokeLinecap="round"
                  />
                </svg>
              )}
            </div>
          ) : (
            // Retícula circular de sigilo/corredor
            <div className="w-2 h-2 rounded-full border border-cyan-400 bg-cyan-400/40 shadow-[0_0_6px_rgba(6,182,212,0.8)]" />
          )}
        </div>

        {/* Prompt de Interacción cuando mira una puerta, trampilla o carcaj */}
        {interactionPrompt && (
          <div className="mt-8 px-4 py-2 rounded-lg bg-slate-950/90 border border-amber-500/80 text-amber-300 text-sm font-bold tracking-wider uppercase shadow-xl flex items-center gap-2 animate-pulse">
            <Key className="w-4 h-4 text-amber-400" />
            <span>{interactionPrompt}</span>
          </div>
        )}
      </div>

      {/* 4. PARTE INFERIOR: ESTADO DEL JUGADOR, STAMINA Y ARCO */}
      <div className="w-full flex flex-col md:flex-row items-end justify-between gap-4">
        {/* Lado Izquierdo: Rol y Salud */}
        <div className="flex flex-col gap-2 bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800/90 backdrop-blur-md min-w-[240px] shadow-2xl">
          {/* Badge de Rol Actual */}
          <div className="flex items-center justify-between pb-1 border-b border-slate-800/70">
            <div className="flex items-center gap-2">
              {isHunter ? (
                <Target className="w-5 h-5 text-amber-400" />
              ) : (
                <Shield className="w-5 h-5 text-cyan-400" />
              )}
              <span className="text-xs font-semibold text-slate-400">ROL ACTUAL:</span>
            </div>
            <span
              className={`text-sm font-black tracking-wider px-2 py-0.5 rounded ${
                isHunter
                  ? 'text-amber-300 bg-amber-950/80 border border-amber-500/40'
                  : 'text-cyan-300 bg-cyan-950/80 border border-cyan-500/40'
              }`}
            >
              {isHunter ? 'CAZADOR' : 'CORREDOR'}
            </span>
          </div>

          {/* Barra de Salud */}
          <div className="flex flex-col gap-1">
            <div className="flex justify-between items-center text-xs font-semibold text-slate-300">
              <span className="flex items-center gap-1.5 text-rose-400">
                <Heart className="w-3.5 h-3.5 fill-rose-500" />
                VIDA
              </span>
              <span className="font-mono text-slate-200">
                {Math.round(playerStats.health)} / {playerStats.maxHealth}
              </span>
            </div>
            <div className="w-full h-2.5 bg-slate-800/90 rounded-full overflow-hidden p-0.5 border border-slate-700/60">
              <div
                className="h-full bg-gradient-to-r from-rose-600 to-rose-400 rounded-full transition-all duration-200"
                style={{ width: `${healthPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Lado Centro: Barra de Stamina (Centrada e Intuitiva) */}
        <div className="flex flex-col items-center gap-1.5 bg-slate-950/80 px-5 py-3 rounded-2xl border border-slate-800/90 backdrop-blur-md min-w-[280px] shadow-2xl">
          <div className="w-full flex justify-between items-center text-xs font-bold tracking-wider">
            <span className="flex items-center gap-1.5 text-emerald-400">
              <Zap className="w-3.5 h-3.5 fill-emerald-400" />
              STAMINA
            </span>
            <span className="font-mono text-slate-300">
              {playerStats.isCrouched ? 'AGACHADO' : playerStats.isSprinting ? 'CORRIENDO' : 'CAMINANDO'}
            </span>
          </div>
          <div className="w-full h-3 bg-slate-800/90 rounded-full overflow-hidden p-0.5 border border-slate-700/60">
            <div
              className={`h-full rounded-full transition-all duration-100 ${
                staminaPercent <= 20
                  ? 'bg-rose-500 animate-pulse'
                  : staminaPercent < 50
                  ? 'bg-amber-400'
                  : 'bg-gradient-to-r from-emerald-500 to-teal-400'
              }`}
              style={{ width: `${staminaPercent}%` }}
            />
          </div>
        </div>

        {/* Lado Derecho: Estado del Arco y Flechas (Solo si es Cazador) o Guía Rápida */}
        <div className="flex flex-col gap-2 bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800/90 backdrop-blur-md min-w-[200px] shadow-2xl">
          {isHunter ? (
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-amber-400 uppercase tracking-wide">FLECHAS:</span>
                <span className="font-mono text-lg font-black text-amber-300 px-2 py-0.5 bg-amber-950/80 rounded border border-amber-500/40">
                  {playerStats.arrows}
                </span>
              </div>
              <div className="text-[11px] text-slate-400">
                {playerStats.canShoot ? 'Mantén Click Izq. para tensar' : 'Recargando arco...'}
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-1 text-[11px] text-slate-300">
              <span className="text-xs font-bold text-cyan-400 uppercase">SUPERVIVENCIA:</span>
              <span>Usa trampillas, puertas y pasajes bajos con [C] o [Ctrl]</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
